# SunBaseData-Assignment
#### This is the assignment repo, it contains all the files that I worked on and all the files required for the assignment.

## Used tools and server - 
#### Eclipse and Tomcat server

## Process -
#### 1. Firstly install the Eclipse.
#### 2. Create the web servlet file.
#### 3. Than write the code for each components when required.
#### 4. After that install the Tomcat Server in Eclipse.
#### 5. Than run the main file on server.

### This is the login screen -
![Login screen](https://github.com/vimaurya/SunbaseData-Assignment/assets/140162190/ca92f1fd-0314-49c7-87ff-c037fa8220eb)

### After loggin in, showing detaills - 
![CustomerDetails](https://github.com/vimaurya/SunbaseData-Assignment/assets/140162190/80bf950c-c118-4fed-a5e1-1a645e69ec8d)

## Add customer - 
![addCustomer](https://github.com/vimaurya/SunbaseData-Assignment/assets/140162190/f2f95f1e-0c63-4402-bcdb-cc96d48075cb)

## Delete customer - 
![DeleteCustomer](https://github.com/vimaurya/SunbaseData-Assignment/assets/140162190/bc1ca682-804e-4dea-b57e-4869d3139b29)

## Update customer - 
![updateCustomer](https://github.com/vimaurya/SunbaseData-Assignment/assets/140162190/837a657b-b1c1-4939-8bd0-4828c214d4ca)
